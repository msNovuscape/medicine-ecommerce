<?php $__env->startSection('content'); ?>

                    <div class = "container">
                    <section class="ps-section--featured">
                        <h3 class="ps-section__title"><?php echo e($brand_name); ?></h3>
                        <div class="ps-section__content">
                            <div class="row m-0">
                                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4 col-lg-2dot4 p-0">
                                        <div class="ps-section__product">
                                            <div class="ps-product ps-product--standard">
                                                <div class="ps-product__thumbnail"><a class="ps-product__image"
                                                        href="<?php echo e(route('frontend.product',['slug' => $medicine->slug])); ?>">
                                                        <figure><?php if($medicine->img == null && $medicine->image_url == null): ?>
                                                    <img src = "https://images.onlineaushadhi.com/img/no-med.png">
                                                <?php else: ?>    
                                                    <img src="<?php echo e($medicine->img ?? $medicine->image_url); ?>" alt="Image unavailable" />
                                                <?php endif; ?>
                                                        </figure>
                                                    </a>
                                                    <div class="ps-product__actions">
                                                        <div class="ps-product__item" title="Wishlist"><a href="javascript:add_to_wishlist(<?php echo e($medicine->id); ?>)" route = "<?php echo e(route('wishlist.add')); ?>" id = "<?php echo e($medicine->id); ?>wishlist"><i
                                                                    class="fa fa-heart-o"></i></a></div>
               
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Add to cart"><a href="javascript:add_to_cart(<?php echo e($medicine->id); ?>)" id="<?php echo e($medicine->id); ?>" route="<?php echo e(route('frontend.add_to_cart')); ?>"
                                                                ><i
                                                                    class="fa fa-shopping-basket"></i></a></div>
                                                    </div>
                                                    <!-- <div class="ps-product__badge">
                                                        <div class="ps-badge ps-badge--sale">Sale</div>
                                                    </div> -->
                                                </div>
                                                <div class="ps-product__content">
                                                    <h5 class="ps-product__title"><a href="<?php echo e(route('frontend.product',['slug' => $medicine->slug])); ?>"><?php echo e($medicine->medicine_name); ?></a></h5>
                                                    <div class="ps-product__meta"><span class="ps-product__price">Rs
                                                    <?php echo e(App\Models\Stock::where('medicine_id',$medicine->id)->orderBy('id','desc')->first()->sp_per_tab ?? $medicine->sp_per_piece); ?></span>
                                                    </div>
                                                    
                                                    <div class="ps-product__desc">
                                                        <ul class="ps-product__list">
                                                            <li>Study history up to 30 days</li>
                                                            <li>Up to 5 users simultaneously</li>
                                                            <li>Has HEALTH certificate</li>
                                                        </ul>
                                                    </div>
                                                    <div class="ps-product__actions ps-product__group-mobile">
                                                        <div class="ps-product__quantity">
                                                            <div class="def-number-input number-input safari_only">
                                                                <button class="minus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                                        class="icon-minus"></i></button>
                                                                <input class="quantity" min="0" name="quantity" value="1"
                                                                    type="number" />
                                                                <button class="plus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                                        class="icon-plus"></i></button>
                                                            </div>
                                                        </div>
                                                        <div class="ps-product__cart"> <a class="ps-btn ps-btn--lblue"
                                                                href="#" data-toggle="modal" data-target="#popupAddcart">Add
                                                                to cart</a></div>
                                                        <div class="ps-product__item cart" data-toggle="tooltip"
                                                            data-placement="left" title="Add to cart"><a href="javascript:add_to_cart(<?php echo e($medicine->id); ?>)" id="<?php echo e($medicine->id); ?>" route="<?php echo e(route('frontend.add_to_cart')); ?>"><i
                                                                    class="fa fa-shopping-basket"></i></a></div>
                                                        <div class="ps-product__item" title="Wishlist"><a
                                                        href="javascript:add_to_wishlist(<?php echo e($medicine->id); ?>)" route = "<?php echo e(route('wishlist.add')); ?>" id = "<?php echo e($medicine->id); ?>wishlist"><i class="fa fa-heart-o"></i></a></div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </section>
                    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/add_to_cart.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/products_by_brand.blade.php ENDPATH**/ ?>