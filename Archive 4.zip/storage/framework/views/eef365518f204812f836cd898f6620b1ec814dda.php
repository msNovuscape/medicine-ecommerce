    <?php $__env->startSection('content'); ?>
                    <div class = "container">
                    <section class="ps-section--featured">
                    <ul class="ps-breadcrumb">
                    <li class="ps-breadcrumb__item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
                    <li class="ps-breadcrumb__item active" aria-current="page">Search Results</li>
                    </ul>
                        <div class="ps-section__content">
                            
                            <div class="row m-0">
                              <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-md-4 col-lg-2dot4 p-0">
                                    <div class="ps-section__product">
                                        <div class="ps-product ps-product--standard">
                                            <div class="ps-product__thumbnail"><a class="ps-product__image"
                                                    href="<?php echo e(route('frontend.product',['slug' => $result->slug])); ?>">

                                                    <?php if($result->img == null && $result->image_url == null): ?>
                                                    <img src = "https://images.onlineaushadhi.com/img/no-med.png">
                                                    <?php else: ?>    
                                                    <img src="<?php echo e($result->img ?? $result->image_url); ?>" alt="Image unavailable" />
                                                    <?php endif; ?>
                                                </a>
                                                <div class="ps-product__actions">
                                                    <div class="ps-product__item" title="Wishlist"><a href="<?php echo e(route('wishlist.add',['product_id' => $result->id])); ?>"><i
                                                                class="fa fa-heart-o"></i></a></div>
                                                    <div class="ps-product__item" data-toggle="tooltip"
                                                        data-placement="left" title="Add to cart"><a href="javascript:add_to_cart(<?php echo e($result->id); ?>)" id="<?php echo e($result->id); ?>" route="<?php echo e(route('frontend.add_to_cart')); ?>"><i
                                                                class="fa fa-shopping-basket"></i></a></div>
                                                </div>
                                                
                                            </div>
                                            <div class="ps-product__content">
                                                <h5 class="ps-product__title"><a href="<?php echo e(route('frontend.product',['slug' => $result->slug])); ?>"><?php echo e($result->medicine_name); ?></a></h5>
                                                <div class="ps-product__meta"><span class="ps-product__price">Rs
                                                <?php echo e(App\Models\Stock::where('medicine_id',$result->id)->orderBy('id','desc')->first()->sp_per_tab ?? $result->sp_per_piece); ?></span>
                                                </div>
                                                
                                                
                                                <div class="ps-product__actions ps-product__group-mobile">
                                                    
                                                    <div class="ps-product__cart"> <a class="ps-btn ps-btn--lblue" href="javascript:add_to_cart(<?php echo e($result->id); ?>)" id="<?php echo e($result->id); ?>" route="<?php echo e(route('frontend.add_to_cart')); ?>">Add
                                                            to cart</a></div>
                                                    <div class="ps-product__item cart" title="Add to cart"><a href="javascript:add_to_cart(<?php echo e($result->id); ?>)" id="<?php echo e($result->id); ?>" route="<?php echo e(route('frontend.add_to_cart')); ?>"><i
                                                                class="fa fa-shopping-basket"></i></a></div>
                                                    <div class="ps-product__item" title="Wishlist"><a
                                                        href="<?php echo e(route('wishlist.add',['product_id' => $result->id])); ?>"><i class="fa fa-heart-o"></i></a>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Pagination -->
                
                            </div>
                            
                            
                        </div>
                    </section>
                    </div>
                <?php $__env->stopSection(); ?>

                    <?php $__env->startSection('scripts'); ?>
                        <script type="text/javascript" src="<?php echo e(asset('js/add_to_cart.js')); ?>"></script>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/search_view.blade.php ENDPATH**/ ?>