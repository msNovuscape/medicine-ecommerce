    <?php $__env->startSection('content'); ?>
    <div class="ps-categogy--promo">
    <div class="container">
                <ul class="ps-breadcrumb">
                    <li class="ps-breadcrumb__item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
                    <li class="ps-breadcrumb__item active" aria-current="page">Testinomial</li>
                </ul>
                <div class="ps-categogy__content">

                <div class = "row">
                <?php $__currentLoopData = $testinomials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testinomial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4">
                        <br/>
                        <div class="cardHealth">
                            <img style = "width:100%" src="<?php echo e($testinomial->image_path); ?>" alt="Avatar">
                            <div class="containerHealth" >
                                <h3 class = "expertName"><b><?php echo e($testinomial->name); ?></b></h3> 
                                <p style = "text-align:center;margin-bottom:-5px"><?php echo e($testinomial->designation); ?></p> 
                                <p style = "text-align:center" ><?php echo e($testinomial->office_name); ?></p> 
                                <p><?php echo e($testinomial->contents); ?></p> 

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- <div class="col-sm">
                        <div class="cardHealth">
                            <img src="img/avatar/img_avatar.png" alt="Avatar">
                            <div class="containerHealth">
                            <h3 class = "expertName"><b>John Doe</b></h3> 
                                <p>Physician</p> 
                                <p>Phone</p> 
                                <p>Email</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="cardHealth">
                            <img src="img/avatar/img_avatar.png" alt="Avatar">
                            <div class="containerHealth">
                            <h3 class = "expertName"><b>John Doe</b></h3> 
                                <p>Physician</p> 
                                <p>Phone</p> 
                                <p>Email</p> 
                            </div>
                        </div>
                    </div> -->
                </div>

                
                </br>
                <!-- <div class = "row">
                    <div class="col-sm">
                        <div class="cardHealth">
                            <img src="img/avatar/img_avatar.png" alt="Avatar">
                            <div class="containerHealth">
                                <h3 class = "expertName"><b>John Doe</b></h3> 
                                <p>Physician</p> 
                                <p>Phone</p> 
                                <p>Email</p> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="cardHealth">
                            <img src="img/avatar/img_avatar.png" alt="Avatar">
                            <div class="containerHealth">
                            <h3 class = "expertName"><b>John Doe</b></h3> 
                                <p>Physician</p> 
                                <p>Phone</p> 
                                <p>Email</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="cardHealth">
                            <img src="img/avatar/img_avatar.png" alt="Avatar">
                            <div class="containerHealth">
                            <h3 class = "expertName"><b>John Doe</b></h3> 
                                <p>Physician</p> 
                                <p>Phone</p> 
                                <p>Email</p> 
                            </div>
                        </div>
                    </div>
                </div> -->
                <?php if($testinomials->count() > 0): ?> 
                    <div class="ps-pagination mb-50">
                        <ul class="pagination">
                        <li><a href="<?php echo e($testinomials->previousPageUrl()); ?>"><i class="fa fa-angle-double-left"></i></a></li>
                                <li class= "active"><a href="<?php echo e($testinomials->path()); ?>?page=1"><?php echo e($testinomials->currentPage()); ?></a></li>
                                <?php if($testinomials->hasMorePages() && $testinomials->count() > 7): ?>
                                <li class= "<?php echo e($testinomials->currentPage() == 2 ?  'active' : ''); ?>"><a href="<?php echo e($testinomials->path()); ?>?page=2">2</a></li>
                                <?php endif; ?>
                                <?php if($testinomials->hasMorePages() && $testinomials->count() > 15): ?>
                                <li class= "<?php echo e($testinomials->currentPage() == 3 ?  'active' : ''); ?>"><a href="<?php echo e($testinomials->path()); ?>?page=3">3</a></li>
                                <?php endif; ?>
                                <?php if($testinomials->hasMorePages() && $testinomials->count() > 23): ?>
                                <li class= "<?php echo e($testinomials->currentPage() >= 4 ?  'active' : ''); ?>"><a href="<?php echo e($testinomials->nextPageUrl()); ?>"><i class="fa fa-angle-double-right"></i></a></li>
                                <?php endif; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/testinomial.blade.php ENDPATH**/ ?>