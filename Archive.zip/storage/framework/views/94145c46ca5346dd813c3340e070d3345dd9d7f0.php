    <?php $__env->startSection('content'); ?>
        <div class="ps-account">
            <div class="container">


                <!-- Account Page's topbar -->
                <div class="row mt-20 mb-30">
                    <div class="col-10 col-md-2 mb-2">
                        <a href="<?php echo e(route('purchase.index')); ?>" class="cs_btn ps-btn--primary">Purchase History</a>
                    </div>

                    <div class="col-10 col-md-2 mb-2">
                        <a href="<?php echo e(route('wishlist.index')); ?>" class="cs_btn ps-btn--primary">View Wish List</a>
                    </div>

                    <div class="col-10 col-md-2 mb-2">
                        <a href="<?php echo e(route('shopping_cart.index')); ?>" class="cs_btn ps-btn--primary">View Cart</a>
                    </div>

                    <div class="col-10 col-md-2 mb-2">
                        <a href="<?php echo e(route('order.index')); ?>" class="cs_btn ps-btn--primary">My Orders</a>
                    </div>
                    <div class="col-10 col-md-2 mb-2">
                        <a href="<?php echo e(route('frontend.list_prescription')); ?>" class="cs_btn ps-btn--primary">My Prescription</a>
                    </div>
                </div>

                <!-- <hr> -->
                <div class="flash-message">
                                            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(Session::has('alert-' . $msg)): ?>

                                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                <div class="row">
                    <div class="col-12 col-md-4">
                        <form action="<?php echo e(route('account.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="ps-form--review">
                                <h2 class="ps-form__title">Change Password</h2>
                                
                                <div class="ps-form__group">
                                    <label class="ps-form__label">New Password *</label>
                                    <div class="input-group">
                                        <input class="form-control ps-form__input" type="password" name = "password" required>
                                        <div class="input-group-append"><a class="fa fa-eye-slash toogle-password"
                                                href="javascript: vois(0);"></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="ps-form__group">
                                    <label class="ps-form__label">Confirm Password *</label>
                                    <div class="input-group">
                                        <input class="form-control ps-form__input" type="password" name = "confirm_password" required>
                                        <div class="input-group-append"><a class="fa fa-eye-slash toogle-password"
                                                href="javascript: vois(0);"></a></div>
                                    </div>
                                </div>
                                <div class="ps-form__submit">
                                    <button class="ps-btn ps-btn--lblue">Update Password</button>

                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-12 col-md-8 card">
                        <form action="<?php echo e(route('account.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="ps-form--review">
                                <h2 class="ps-form__title">Update Information</h2>

                                <div class="ps-form__group">
                                    <label class="ps-form__label">Full Name *</label>
                                    <input class="form-control ps-form__input" type="text" required name = "name" value = "<?php echo e($user->name); ?>">
                                </div>

                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div class="ps-form__group">
                                            <label class="ps-form__label">Phone *</label>
                                            <input type='text' name = "phone" required value = "<?php echo e($user->phone); ?>" class="form-control ps-form__input">
                                        </div>
                                    </div>

                                    <div class="col-12 col-md-6">
                                        <div class="ps-form__group">
                                            <label class="ps-form__label">Address *</label>
                                            <input type='text' name = "address" required value = "<?php echo e($user->address); ?>" class="form-control ps-form__input">
                                        </div>
                                    </div>
                                </div>

                                 <div class="ps-form__group">
                                    <label class="ps-form__label">Email address *</label>
                                    <input class="form-control ps-form__input" type="email" required name = "email" value = "<?php echo e($user->email); ?>">
                                </div>
                                 <input type = "hidden" name = 'id' value = '<?php echo e($user->id); ?>'>  
                                <div class="ps-form__submit">
                                    <button class="ps-btn ps-btn--lblue">Update Information</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>    
   
    
  

  
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/users/account.blade.php ENDPATH**/ ?>