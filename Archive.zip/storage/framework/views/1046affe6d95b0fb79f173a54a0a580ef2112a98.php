 
    <?php $__env->startSection('content'); ?>       
        <div class="ps-wishlist">
            <div class="container">
            <div class="row mt-20 mb-30">
                    <div class="col-10 col-md-2 mb-10">
                        <a href="<?php echo e(route('purchase.index')); ?>" class="cs_btn ps-btn--primary">Purchase History</a>
                    </div>

                    <div class="col-10 col-md-2 mb-10">
                        <a href="<?php echo e(route('wishlist.index')); ?>" class="cs_btn ps-btn--primary">View Wish List</a>
                    </div>

                    <div class="col-10 col-md-2 mb-10">
                        <a href="<?php echo e(route('shopping_cart.index')); ?>" class="cs_btn ps-btn--primary">View Cart</a>
                    </div>

                    <div class="col-10 col-md-2 mb-10">
                        <a href="<?php echo e(route('order.index')); ?>" class="cs_btn ps-btn--primary">My Orders</a>
                    </div>
                    <div class="col-10 col-md-2 mb-10">
                        <a href="<?php echo e(route('frontend.list_prescription')); ?>" class="cs_btn ps-btn--primary">My Prescription</a>
                    </div>
            </div>
                <ul class="ps-breadcrumb" style = "margin-top:-35px">
                    <li class="ps-breadcrumb__item"><a href="<?php echo e(route('frontend.index')); ?>">Home</a></li>
                    <li class="ps-breadcrumb__item"><a href="<?php echo e(route('account.index')); ?>">Account</a></li>
                    <li class="ps-breadcrumb__item active" aria-current="page">Purchase History</li>
                </ul>
                <h3 class="ps-wishlist__title">Purchase History</h3>
                <div class="ps-wishlist__content" style = "margin-top:-20px">

                    <!-- WishList to be displayed for small resolutions only -->
                    <ul class="ps-wishlist__list">
                    <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li>
                            <div class="ps-product ps-product--wishlist">
                               
                                <div class="ps-product__content">
                                    </h5>
                                    <div class="ps-product__row">
                                        <div class="ps-product__label">Order No.:</div>
                                        <div class="ps-product__value"><span class="ps-product__price sale"><?php echo e($purchase->id); ?>

                                        </div>
                                    </div>
                                    <div class="ps-product__row ps-product__stock">
                                        <div class="ps-product__label">Order Date.:</div>
                                        <div class="ps-product__value"><span class="ps-product__out-stock "><?php echo e($purchase->date); ?>

                                            </span>
                                        </div>
                                    </div>
                                    <div class="ps-product__row ps-product__quantity">
                                        <div class="ps-product__label">Delivery Date:</div>
                                        <div class="ps-product__value"><?php echo e($purchase->delivery_date); ?></div>
                                    </div>
                                    <div class="ps-product__row ps-product__subtotal">
                                        <div class="ps-product__label">Total(NRs):</div>
                                        <div class="ps-product__value">Rs <?php echo e($purchase->total_amount); ?></div>
                                    </div>
                                    <div class="ps-product__row ps-product__subtotal">
                                        <div class="ps-product__label">Discount(NRs):</div>
                                        <div class="ps-product__value">Rs <?php echo e($purchase->discount_amount); ?></div>
                                    </div>
                                    <div class="ps-product__row ps-product__subtotal">
                                        <div class="ps-product__label">Net Price(NRs):</div>
                                        <div class="ps-product__value">Rs <?php echo e($purchase->net_amount); ?></div>
                                    </div>
                                    <div class="ps-product__cart">
                                        <a href = "javascript:viewDetails(<?php echo e($purchase->id); ?>)" route = "<?php echo e(route('purchase.view_details')); ?>" id = "<?php echo e($purchase->id); ?>" class="ps-btn ps-btn--lblue">Details</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>
                        <div class="ps-product ps-product--wishlist">
                            You donot have any complete order till now.
                        </div>
                    </li>        
                    <?php endif; ?>    
                        
                    </ul>
                    <!-- End WishList to be displayed for small resolutions only -->

                    <div class="ps-wishlist__table">
                        <table class="table ps-table ps-table--product">
                            <thead>
                                <tr>
                                    <th class="ps-product__name">SN No.</th>
                                    <th class="ps-product__name">Order No.</th>
                                    <th class="ps-product__meta">Order Date</th>
                                    <th class="ps-product__status">Delivery Date</th>
                                    <th class="ps-product__cart">Total(NRs)</th>
                                    <th class="ps-product__cart">Discount(NRs)</th>
                                    <th class="ps-product__cart">Net Price(NRs)</th>
                                    <th class="ps-product__cart">Details</th>
                                </tr>
                            </thead>
                            <tbody style = "line-height:0.2px">
                                <?php ($i = ($purchases->currentpage()-1)* $purchases->perpage() + 1); ?>
                                <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr height = "10px">
                                        <td class="ps-product__name"> <?php echo e($i); ?>

                                        </td>
                                        <td class="ps-product__meta"> <?php echo e($purchase->id); ?></span>
                                        </td>
                                        <td class="cs_out_of_stock"> <?php echo e($purchase->date); ?>

                                        </td>
                                        <td class="cs_out_of_stock"> <?php echo e($purchase->delivery_date); ?>

                                        </td>
                                        <td class="ps-product__cart">
                                            <?php echo e($purchase->total_amount); ?>

                                        </td>
                                        <td class="ps-product__cart">
                                            <?php echo e($purchase->discount_amount); ?>

                                        </td>
                                        <td class="ps-product__cart">
                                            <?php echo e($purchase->net_amount); ?>

                                        </td>
                                        <td class="ps-product__cart" data-toggle="tooltip" data-placement="left" title="View Details">
                                            <a href = "javascript:viewDetails(<?php echo e($purchase->id); ?>)" route = "<?php echo e(route('purchase.view_details')); ?>" id = "<?php echo e($purchase->id); ?>">View</a>
                                        </td>
                                    </tr>
                                <?php ($i++); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td colspan = "16" class="ps-product__cart">You donot have any complete order till now.</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>

                <!-- Pagination -->
                <?php if($purchases->lastPage() > 1): ?>
                    <div class="ps-pagination mb-50">
                        <ul class="pagination">
                            <li class="<?php echo e(($purchases->currentPage() == 1) ? 'disabled' : ''); ?>">
                                <a href="<?php echo e($purchases->url(1)); ?>"><i class="fa fa-angle-double-left"></i></a>
                            </li>
                            <?php for($i = 1; $i <= $purchases->lastPage(); $i++): ?>
                                <li class="<?php echo e(($purchases->currentPage() == $i) ? ' active' : ''); ?>">
                                    <a href="<?php echo e($purchases->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="<?php echo e(($purchases->currentPage() == $purchases->lastPage()) ? 'disabled' : ''); ?>" >
                                <a href="<?php echo e($purchases->url($purchases->currentPage()+1)); ?>"><i class="fa fa-angle-double-right"></i></a>
                            </li>
                        </ul>
                    </div>    
                <?php endif; ?>        
            </div>
        </div> 
        <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/add_to_cart.js')); ?>"></script>
<?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>    
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/users/purchase_history.blade.php ENDPATH**/ ?>