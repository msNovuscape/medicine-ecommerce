<?php $__env->startSection('content'); ?>

<div class="ps-wishlist">
            <div class="container">
                <ul class="ps-breadcrumb">
                    <li class="ps-breadcrumb__item"><a href="index.html">Home</a></li>
                    <li class="ps-breadcrumb__item active" aria-current="page">Wishlist</li>
                </ul>
                <h3 class="ps-wishlist__title">My wishlist</h3>
                <div class="ps-wishlist__content">

                    <!-- WishList to be displayed for small resolutions only -->
                    <ul class="ps-wishlist__list">
                        <!-- <li>
                            <div class="ps-product ps-product--wishlist">
                                <div class="ps-product__remove"><a href="#"><i class="icon-cross"></i></a></div>
                                <div class="ps-product__thumbnail"><a class="ps-product__image" href="product.html">
                                        <figure><img src="img/products/001.jpg" alt="alt" /><img
                                                src="img/products/009.jpg" alt="alt" />
                                        </figure>
                                    </a></div>
                                <div class="ps-product__content">
                                    <h5 class="ps-product__title"><a href="product.html">Digital Thermometer X30-Pro</a>
                                    </h5>
                                    <div class="ps-product__row">
                                        <div class="ps-product__label">Price:</div>
                                        <div class="ps-product__value"><span class="ps-product__price sale">Rs
                                                77.65</span><span class="ps-product__del">Rs 80.65</span>
                                        </div>
                                    </div>
                                    <div class="ps-product__row ps-product__stock">
                                        <div class="ps-product__label">Stock:</div>
                                        <div class="ps-product__value"><span class="ps-product__out-stock ">Out of stock
                                            </span>
                                        </div>
                                    </div>
                                    <div class="ps-product__cart">
                                        <a href="product.html" class="ps-btn ps-btn--lblue">Add to cart</a>
                                    </div>

                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ps-product ps-product--wishlist">
                                <div class="ps-product__remove"><a href="#"><i class="icon-cross"></i></a></div>
                                <div class="ps-product__thumbnail"><a class="ps-product__image" href="product.html">
                                        <figure><img src="img/products/011.jpg" alt="alt" />
                                        </figure>
                                    </a></div>
                                <div class="ps-product__content">
                                    <h5 class="ps-product__title"><a href="product.html">Hill-Rom Affinity III Progressa
                                            iBed</a></h5>
                                    <div class="ps-product__row">
                                        <div class="ps-product__label">Price:</div>
                                        <div class="ps-product__value"><span class="ps-product__price">Rs 488.23</span>
                                        </div>
                                    </div>
                                    <div class="ps-product__row ps-product__stock">
                                        <div class="ps-product__label">Stock:</div>
                                        <div class="ps-product__value"><span class="ps-product__in-stock">In
                                                Stock</span>
                                        </div>
                                    </div>
                                    <div class="ps-product__cart">
                                        <a href="product.html" class="ps-btn ps-btn--lblue">Add to cart</a>
                                    </div>

                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="ps-product ps-product--wishlist">
                                <div class="ps-product__remove"><a href="#"><i class="icon-cross"></i></a></div>
                                <div class="ps-product__thumbnail"><a class="ps-product__image" href="product.html">
                                        <figure><img src="img/products/012.jpg" alt="alt" /><img
                                                src="img/products/013.jpg" alt="alt" />
                                        </figure>
                                    </a></div>
                                <div class="ps-product__content">
                                    <h5 class="ps-product__title"><a href="product.html">Hill-Rom Affinity III Progressa
                                            iBed</a></h5>
                                    <div class="ps-product__row">
                                        <div class="ps-product__label">Price:</div>
                                        <div class="ps-product__value"><span class="ps-product__price">Rs 436.87</span>
                                        </div>
                                    </div>
                                    <div class="ps-product__row ps-product__stock">
                                        <div class="ps-product__label">Stock:</div>
                                        <div class="ps-product__value"><span class="ps-product__in-stock">In
                                                Stock</span>
                                        </div>
                                    </div>
                                    <div class="ps-product__cart">
                                        <a href="product.html" class="ps-btn ps-btn--lblue">Add to cart</a>
                                    </div>

                                </div>
                            </div>
                        </li> -->
                    </ul>
                    <!-- End WishList to be displayed for small resolutions only -->

                    <div class="ps-wishlist__table">
                        <table class="table ps-table ps-table--product">
                            <thead>
                                <tr>
                                    <th class="ps-product__remove"></th>
                                    <th class="ps-product__thumbnail"></th>
                                    <th class="ps-product__name">Product name</th>
                                    <th class="ps-product__meta">Unit price</th>
                                    <th class="ps-product__status">Stock status</th>
                                    <th class="ps-product__cart"></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $wishlist_medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist_medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <tr>
                                    <td class="ps-product__remove"> <a href="<?php echo e(route('wishlist.remove',['medicine_id' => $wishlist_medicine->id])); ?>"><i class="icon-cross"></i></a></td>
                                    <td class="ps-product__thumbnail"><a class="ps-product__image" href="product.html">
                                            <figure><img src="img/products/001.jpg" alt></figure>
                                        </a></td>
                                    <td class="ps-product__name"> <a href="product.html"><?php echo e($wishlist_medicine->medicine_name); ?></a>
                                    </td>
                                    <td class="ps-product__meta"> <span class="ps-product__price sale">Rs
                                            <?php echo e($wishlist_medicine->sp_per_piece); ?></span><span class="ps-product__del">Rs 80.65</span>
                                    </td>
                                    <td class="cs_out_of_stock"> <span><?php echo e($wishlist_medicine->availability == 1 ? 'In Stock' : 'Out of stock'); ?> </span>
                                    </td>
                                    <td class="ps-product__cart">
                                        <a href="product.html" class="ps-btn ps-btn--lblue">Add to cart</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan = 6>Wishlist is empty</td>
                                </tr>
                            <?php endif; ?>
                                
                                <!-- <tr>
                                    <td class="ps-product__remove"> <a href="#"><i class="icon-cross"></i></a></td>
                                    <td class="ps-product__thumbnail"><a class="ps-product__image" href="product.html">
                                            <figure><img src="img/products/011.jpg" alt></figure>
                                        </a></td>
                                    <td class="ps-product__name"> <a href="product.html">Hill-Rom Affinity III Progressa
                                            iBed</a></td>
                                    <td class="ps-product__meta"> <span class="ps-product__price">Rs 488.23</span>
                                    </td>
                                    <td class="ps-product__status"> <span>In Stock</span>
                                    </td>
                                    <td class="ps-product__cart">
                                        <a href="product.html" class="ps-btn ps-btn--lblue">Add to cart</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="ps-product__remove"> <a href="#"><i class="icon-cross"></i></a></td>
                                    <td class="ps-product__thumbnail"><a class="ps-product__image" href="product.html">
                                            <figure><img src="img/products/012.jpg" alt></figure>
                                        </a></td>
                                    <td class="ps-product__name"> <a href="product.html">Hill-Rom Affinity III Progressa
                                            iBed</a></td>
                                    <td class="ps-product__meta"> <span class="ps-product__price">Rs 436.87</span>
                                    </td>
                                    <td class="ps-product__status"> <span>In Stock</span>
                                    </td>
                                    <td class="ps-product__cart">
                                        <a href="product.html" class="ps-btn ps-btn--lblue">Add to cart</a>
                                    </td>
                                </tr> -->
                            </tbody>
                        </table>
                    </div>

                </div>

                <!-- Pagination -->
                <div class="ps-pagination mb-50">
                    <ul class="pagination">
                        <li><a href="#"><i class="fa fa-angle-double-left"></i></a></li>
                        <li class="active"><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/wishlist.blade.php ENDPATH**/ ?>