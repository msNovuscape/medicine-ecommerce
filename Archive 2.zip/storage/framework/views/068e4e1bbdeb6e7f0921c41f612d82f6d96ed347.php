    <?php $__env->startSection('content'); ?>
        <div class="ps-account">
            <div class="container">


                <!-- Account Page's topbar -->
              

                <!-- <hr> -->
                <div class="flash-message">
                                            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(Session::has('alert-' . $msg)): ?>

                                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                <div class="row">
                    <!-- <div class="col-12 col-md-4">
                        <form action="<?php echo e(route('account.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="ps-form--review">
                                <h2 class="ps-form__title">Change Password</h2>
                                
                                <div class="ps-form__group">
                                    <label class="ps-form__label">New Password *</label>
                                    <div class="input-group">
                                        <input class="form-control ps-form__input" type="password" name = "password" required>
                                        <div class="input-group-append"><a class="fa fa-eye-slash toogle-password"
                                                href="javascript: vois(0);"></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="ps-form__group">
                                    <label class="ps-form__label">Confirm Password *</label>
                                    <div class="input-group">
                                        <input class="form-control ps-form__input" type="password" name = "confirm_password" required>
                                        <div class="input-group-append"><a class="fa fa-eye-slash toogle-password"
                                                href="javascript: vois(0);"></a></div>
                                    </div>
                                </div>
                                <div class="ps-form__submit">
                                    <button class="ps-btn ps-btn--lblue">Update Password</button>

                                </div>
                            </div>
                        </form>
                    </div> -->
                    <div class="col-12 col-md-12 card">
                        <form action="<?php echo e(route('frontend.add_prescription')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="ps-form--review">
                                <h2 class="ps-form__title">Upload Prescription</h2>

        

                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div class="ps-form__group">
                                            <label class="ps-form__label">Choose your files*</label>
                                            <input type='file' name = "attachment[]" required  class="form-control ps-form__input" multiple = "multiple">
                                        </div>
                                        <div class="input-group-btn"> 

                                    </div>
                                    <!-- <button class="btn btn-success" type="button"> <i class="fldemo glyphicon glyphicon-plus"></i>Add</button> -->
                                    </div>
                                    <!-- <div class="clone fade">
                                    <div class="realprocode control-group lst input-group" style="margin-top:10px">
                                        <input type="file" name="filenames[]" class="myfrm form-control">
                                        <div class="input-group-btn"> 
                                        <button class="btn btn-danger" type="button"><i class="fldemo glyphicon glyphicon-remove"></i> Remove</button>
                                        </div>
                                    </div>
                                    </div> -->

                                    <div class="col-12 col-md-6">
                                        <div class="ps-form__group">
                                            <label class="ps-form__label">Remarks </label>
                                            <input type='text' name = "remarks" required  class="form-control ps-form__input">
                                        </div>
                                    </div>

                                </div>

                          
                                <div class="ps-form__submit">
                                    <button class="ps-btn ps-btn--lblue">Submit</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <script type="text/javascript">
        $(document).ready(function() {
        $(".btn-success").click(function(){ 
            var lsthmtl = $(".clone").html();
            $(".increment").after(lsthmtl);
        });
        $("body").on("click",".btn-danger",function(){ 
            $(this).parents(".realprocode").remove();
        });
        });
    </script>
   
    
  

  
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/users/prescription.blade.php ENDPATH**/ ?>