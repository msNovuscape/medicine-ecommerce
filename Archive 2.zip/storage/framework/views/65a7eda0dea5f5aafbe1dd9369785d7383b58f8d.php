<?php $__env->startSection('content'); ?>
        <div class="ps-account">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <img src="https://images.onlineaushadhi.com/img/aregister.png" alt="alt" height = "60%" />
                    </div>
                    <div class="col-12 col-md-6">
                    <form action="<?php echo e(route('post_register')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="flash-message">
                                
                                
                                                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(Session::has('alert-validation-' . $msg)): ?>

                                                    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-validation-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                <div style = "" class="ps-form--review">
                                    <h2 class="ps-form__title">Register</h2>
                                    <?php if($errors->has('email')): ?>
                                            <div class="alert alert-danger"><?php echo e($errors->first('email')); ?></div>
                                        <?php endif; ?>
                                        <?php if($errors->has('password')): ?>
                                            <div class="alert alert-danger"><?php echo e($errors->first('password')); ?></div>
                                        <?php endif; ?>
                                    <div class = "row">
                                        <div class="col-12 col-md-6">
                                            <div class="ps-form__group">
                                                <label class="ps-form__label">Full Name *</label>
                                                <input class="form-control ps-form__input" type="text" name = "name" value = "<?php echo e(old('name')); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="ps-form__group">
                                                <label class="ps-form__label">Address *</label>
                                                <input type='text' name = "address" value = "<?php echo e(old('address')); ?>" class="form-control ps-form__input" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            <div class="ps-form__group">
                                                <label class="ps-form__label">Phone *</label>
                                                <input type='text' name = "phone" value = "<?php echo e(old('phone')); ?>" class="form-control ps-form__input" required>
                                            </div>
                                        </div>

                                        <div class="col-12 col-md-6">
                                            <div class="ps-form__group">
                                                <label class="ps-form__label">Email address *</label>
                                                <input class="form-control ps-form__input" type="email" name = "email" value = "<?php echo e(old('email')); ?>" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12 col-md-6">
                                            <div class="ps-form__group">
                                                <label class="ps-form__label">Password *</label>
                                                <div class="input-group">
                                                    <input class="form-control ps-form__input" type="password" name = "password" required>
                                                    <div class="input-group-append"><a
                                                            class="fa fa-eye-slash toogle-password"
                                                            href="javascript: vois(0);"></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="ps-form__group">
                                                <label class="ps-form__label">Confirm Password *</label>
                                                <div class="input-group">
                                                    <input class="form-control ps-form__input" type="password" name = "confirm_password" required>
                                                    <div class="input-group-append"><a
                                                            class="fa fa-eye-slash toogle-password"
                                                            href="javascript: vois(0);"></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="ps-form__submit">
                                        <button class="ps-btn ps-btn--lblue">Register</button>
                                    </div>
                                    Already registered?<a class="ps-account__link" href="<?php echo e(route('login')); ?>">Login here.</a>
                    </form>
                                
                            
                </div>    
            </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>        
   
    
   
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ausadhipasal/resources/views/frontend/users/register_form.blade.php ENDPATH**/ ?>